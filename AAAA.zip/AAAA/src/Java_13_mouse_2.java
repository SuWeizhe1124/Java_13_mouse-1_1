import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Java_13_mouse_2  extends  Frame implements ActionListener {
	   static int i = 0;
	    Button btnAdd = new Button();
	    Button btnSub = new Button();
	    Button btnExit = new Button();

	    public Java_13_mouse_2(){
	        this.setLocation(100,50); //位置
	        this.setTitle("Click"); //標題
	        this.setSize(500,500); //標單寬度,長度
	        this.setVisible(true); //顯示表單
	        this.setLayout(null); //自行定義版面設置

	        btnAdd.setLabel("Add 1");
	        btnAdd.setBounds(30,50,60,40);
	        btnAdd.setBackground(Color.blue);

	        btnSub.setLabel("Sub 1");
	        btnSub.setBounds(120,50,60,40);
	        btnSub.setBackground(Color.blue);
	        
	        btnExit.setLabel("Exit");
	        btnExit.setBounds(30,100,150,40);

	        this.add(btnAdd);
	        this.add(btnSub);
	        this.add(btnExit);
	        //加入事件處理
	        btnAdd.addActionListener(this);
	        btnSub.addActionListener(this);
	        btnExit.addActionListener(this);
	    }
	    public static void main(String[] args) {
	        Java_13_mouse_2 frm = new Java_13_mouse_2();
	    }
	    @Override
	    public void actionPerformed(ActionEvent e) {
	        if(e.getSource() == btnAdd) i++;
	        else if(e.getSource() == btnSub) i--;
	        else System.exit(0);
	        this.setTitle(String.valueOf(i));
	    }
}
